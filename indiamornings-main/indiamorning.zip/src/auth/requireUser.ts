import { headers } from "next/headers";
import { getAuthCookies } from "./cookies";
import { verifyAccess } from "./jwt";

export async function getRequestIp(): Promise<string | undefined> {
  const h = await headers();
  return h.get("x-forwarded-for")?.split(",")[0]?.trim() || h.get("x-real-ip") || undefined;
}

export async function requireUser() {
  const { access } = await getAuthCookies();
  if (!access) {
    const err = new Error("Unauthorized");
    (err as any).status = 401;
    throw err;
  }
  const payload = verifyAccess(access);
  return { id: payload.sub, role: payload.role };
}
