export function jsonOk(data: unknown, init?: ResponseInit) {
  return Response.json(data, { status: 200, ...init });
}

export function jsonCreated(data: unknown) {
  return Response.json(data, { status: 201 });
}

export function jsonError(message: string, status: number = 400, extra?: any) {
  return Response.json({ message, ...(extra ? { extra } : {}) }, { status });
}
