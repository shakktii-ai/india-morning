import SiteHeader from "./_components/SiteHeader";
import CategoryTabs from "./_components/CategoryTabs";
import FiltersBar from "./_components/FiltersBar";
import ArticleCard from "./_components/ArticleCard";

export default async function Home({ searchParams }: { searchParams: Promise<{ region?: string; lang?: string }> }) {
  const { region = "MAHARASHTRA", lang = "EN" } = await searchParams;
  const base = process.env.NEXT_PUBLIC_BASE_URL || "";
  const res = await fetch(`${base}/api/public/home?region=${encodeURIComponent(region)}&lang=${encodeURIComponent(lang)}`, { cache: "no-store" });
  const data = await res.json();

  return (
    <>
      <SiteHeader />
      <FiltersBar />
      <CategoryTabs active="" />

      <main className="container" style={{ paddingTop: 14, paddingBottom: 40 }}>
        <div className="grid" style={{ gridTemplateColumns: "2fr 1fr" }}>
          <section>
            <h1 style={{ fontSize: 28, margin: "10px 0 6px" }}>Top Stories</h1>
            <div className="grid">
              {data.topStories?.map((a: any) => <ArticleCard key={a.id} a={a} />)}
            </div>
          </section>

          <aside>
            <div className="card">
              <h3 style={{ marginTop: 0 }}>Recent Posts</h3>
              <div style={{ display: "grid", gap: 10 }}>
                {data.recent?.map((r: any) => (
                  <a key={r.slug} href={`/article/${r.slug}`} style={{ fontWeight: 700 }}>
                    {r.title}
                    <div style={{ fontSize: 12, opacity: 0.7 }}>{r.publishedAt ? new Date(r.publishedAt).toLocaleDateString() : ""}</div>
                  </a>
                ))}
              </div>
            </div>
          </aside>
        </div>
      </main>
    </>
  );
}
