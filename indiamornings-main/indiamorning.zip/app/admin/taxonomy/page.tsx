"use client";

import { useEffect, useState } from "react";

export default function TaxonomyPage() {
  const [categories, setCategories] = useState<any[]>([]);
  const [tags, setTags] = useState<any[]>([]);
  const [catName, setCatName] = useState("");
  const [tagName, setTagName] = useState("");

  async function load() {
    const [c, t] = await Promise.all([fetch("/api/taxonomy/categories"), fetch("/api/taxonomy/tags")]);
    const cd = await c.json(); const td = await t.json();
    setCategories(cd.categories || []);
    setTags(td.tags || []);
  }

  useEffect(() => { load(); }, []);

  async function addCategory() {
    const r = await fetch("/api/taxonomy/categories", { method:"POST", headers:{ "content-type":"application/json" }, body: JSON.stringify({ name: catName }) });
    const d = await r.json().catch(()=>({}));
    if (!r.ok) { alert(d?.message || "Failed"); return; }
    setCatName(""); await load();
  }

  async function addTag() {
    const r = await fetch("/api/taxonomy/tags", { method:"POST", headers:{ "content-type":"application/json" }, body: JSON.stringify({ name: tagName }) });
    const d = await r.json().catch(()=>({}));
    if (!r.ok) { alert(d?.message || "Failed"); return; }
    setTagName(""); await load();
  }

  return (
    <div className="grid" style={{ gridTemplateColumns: "1fr 1fr", gap: 14 }}>
      <div className="card">
        <h2 style={{ marginTop: 0 }}>Categories</h2>
        <div style={{ display:"flex", gap: 10 }}>
          <input className="input" placeholder="New category name" value={catName} onChange={e=>setCatName(e.target.value)} />
          <button className="btn btnPrimary" onClick={addCategory}>Add</button>
        </div>
        <div style={{ marginTop: 12, display:"grid", gap: 8 }}>
          {categories.map((c:any)=>(
            <div key={c.id} className="card" style={{ boxShadow: "none" }}>
              <b>{c.name}</b>
              <div style={{ fontSize: 12, opacity: 0.7 }}>{c.slug}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="card">
        <h2 style={{ marginTop: 0 }}>Tags</h2>
        <div style={{ display:"flex", gap: 10 }}>
          <input className="input" placeholder="New tag name" value={tagName} onChange={e=>setTagName(e.target.value)} />
          <button className="btn btnPrimary" onClick={addTag}>Add</button>
        </div>
        <div style={{ marginTop: 12, display:"grid", gap: 8 }}>
          {tags.map((t:any)=>(
            <div key={t.id} className="card" style={{ boxShadow: "none" }}>
              <b>{t.name}</b>
              <div style={{ fontSize: 12, opacity: 0.7 }}>{t.slug}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
