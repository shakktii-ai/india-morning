"use client";

import { useState } from "react";
import Link from "next/link";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setErr(null);
    const r = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ email, password })
    });
    if (!r.ok) {
      const d = await r.json().catch(()=>({}));
      setErr(d?.message || "Login failed");
      return;
    }
    window.location.href = "/admin";
  }

  return (
    <div style={{ minHeight: "100vh", display: "grid", placeItems: "center", padding: 16, background: "#F6F7FB" }}>
      <div className="card" style={{ width: "100%", maxWidth: 420 }}>
        <h2 style={{ marginTop: 0 }}>India Mornings CMS Login</h2>
        <form onSubmit={submit} style={{ display: "grid", gap: 10 }}>
          <input className="input" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
          <input className="input" placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
          {err ? <div style={{ color: "#DC2626", fontWeight: 700 }}>{err}</div> : null}
          <button className="btn btnPrimary" type="submit">Login</button>
        </form>
        <div style={{ fontSize: 12, opacity: 0.7, marginTop: 10 }}>
          <Link href="/">← Back to site</Link>
        </div>
      </div>
    </div>
  );
}
