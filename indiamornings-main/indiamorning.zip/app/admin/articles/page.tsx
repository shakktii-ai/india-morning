"use client";

import { useEffect, useMemo, useState } from "react";

type Article = any;

export default function ArticlesPage() {
  const [articles, setArticles] = useState<Article[]>([]);
  const [status, setStatus] = useState<string>("");

  const [title, setTitle] = useState("");
  const [excerpt, setExcerpt] = useState("");
  const [contentHtml, setContent] = useState("<p>Hello India Mornings.</p>");
  const [coverImageUrl, setCover] = useState("");
  const [language, setLanguage] = useState("EN");
  const [region, setRegion] = useState("MAHARASHTRA");

  async function load() {
    const q = status ? `?status=${encodeURIComponent(status)}` : "";
    const r = await fetch(`/api/articles${q}`);
    const d = await r.json();
    if (!r.ok) { alert(d?.message || "Failed to load"); return; }
    setArticles(d.articles || []);
  }

  useEffect(() => { load(); }, [status]);

  async function create() {
    const r = await fetch("/api/articles", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ title, excerpt, contentHtml, coverImageUrl: coverImageUrl || undefined, language, region, tagIds: [] })
    });
    if (!r.ok) {
      const d = await r.json().catch(()=>({}));
      alert(d?.message || "Failed");
      return;
    }
    setTitle(""); setExcerpt(""); setCover("");
    await load();
    alert("Draft created");
  }

  async function submit(id: string) {
    const r = await fetch(`/api/articles/${id}/submit`, { method: "POST" });
    const d = await r.json().catch(()=>({}));
    if (!r.ok) { alert(d?.message || "Failed"); return; }
    await load();
  }

  async function del(id: string) {
    if (!confirm("Delete?")) return;
    const r = await fetch(`/api/articles/${id}`, { method: "DELETE" });
    const d = await r.json().catch(()=>({}));
    if (!r.ok) { alert(d?.message || "Failed"); return; }
    await load();
  }

  const grouped = useMemo(() => articles, [articles]);

  return (
    <div className="grid" style={{ gap: 14 }}>
      <div className="card">
        <h2 style={{ marginTop: 0 }}>Create Draft</h2>
        <div className="grid" style={{ gridTemplateColumns: "1fr 1fr" }}>
          <input className="input" placeholder="Title" value={title} onChange={e=>setTitle(e.target.value)} />
          <input className="input" placeholder="Cover Image URL (optional)" value={coverImageUrl} onChange={e=>setCover(e.target.value)} />
          <select className="select" value={language} onChange={e=>setLanguage(e.target.value)}>
            <option value="EN">English</option>
            <option value="MR">Marathi</option>
            <option value="HI">Hindi</option>
          </select>
          <select className="select" value={region} onChange={e=>setRegion(e.target.value)}>
            <option value="MAHARASHTRA">MAHARASHTRA</option>
            <option value="INDIA">INDIA</option>
          </select>
        </div>
        <textarea className="textarea" placeholder="Excerpt" value={excerpt} onChange={e=>setExcerpt(e.target.value)} style={{ marginTop: 10, height: 70 }} />
        <textarea className="textarea" value={contentHtml} onChange={e=>setContent(e.target.value)} style={{ marginTop: 10, height: 160 }} />
        <div style={{ marginTop: 10, display: "flex", gap: 10 }}>
          <button className="btn btnPrimary" onClick={create}>Create Draft</button>
        </div>
        <div style={{ fontSize: 12, opacity: 0.7, marginTop: 8 }}>
          Tip: contentHtml expects HTML. You can paste &lt;p&gt;...&lt;/p&gt;
        </div>
      </div>

      <div className="card">
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", gap: 10, flexWrap:"wrap" }}>
          <h2 style={{ margin: 0 }}>Articles</h2>
          <div style={{ display:"flex", gap: 10, alignItems:"center" }}>
            <label style={{ fontWeight: 800 }}>Filter status</label>
            <select className="select" value={status} onChange={e=>setStatus(e.target.value)} style={{ width: 180 }}>
              <option value="">All</option>
              <option value="DRAFT">DRAFT</option>
              <option value="IN_REVIEW">IN_REVIEW</option>
              <option value="APPROVED">APPROVED</option>
              <option value="PUBLISHED">PUBLISHED</option>
              <option value="REJECTED">REJECTED</option>
            </select>
            <button className="btn btnGhost" onClick={load}>Refresh</button>
          </div>
        </div>

        <div style={{ display:"grid", gap: 10, marginTop: 12 }}>
          {grouped.map((a:any) => (
            <div key={a.id} className="card" style={{ boxShadow: "none" }}>
              <div style={{ display:"flex", justifyContent:"space-between", gap: 12, alignItems:"flex-start" }}>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 12, opacity: 0.7 }}>{a.status} • {a.language} • {a.region}</div>
                  <div style={{ fontWeight: 900, fontSize: 16 }}>{a.title}</div>
                  <div style={{ fontSize: 12, opacity: 0.7 }}>Slug: {a.slug}</div>
                </div>
                <div style={{ display:"flex", gap: 8, flexWrap:"wrap", justifyContent:"flex-end" }}>
                  {(a.status === "DRAFT" || a.status === "REJECTED") ? (
                    <button className="btn btnPrimary" onClick={()=>submit(a.id)}>Submit</button>
                  ) : null}
                  <a className="btn btnGhost" href={`/article/${a.slug}`} target="_blank">View</a>
                  <button className="btn btnGhost" onClick={()=>del(a.id)}>Delete</button>
                </div>
              </div>
              {a.reviewNotes ? <div style={{ marginTop: 8, color:"#DC2626", fontWeight: 800 }}>Review notes: {a.reviewNotes}</div> : null}
            </div>
          ))}
          {grouped.length === 0 ? <div style={{ opacity: 0.7 }}>No articles yet.</div> : null}
        </div>
      </div>
    </div>
  );
}
