import { requireUser } from "@/src/auth/requireUser";
import { prisma } from "@/src/prisma";

export default async function AdminHome() {
  let actor: any = null;
  try {
    actor = await requireUser();
  } catch {
    return (
      <div className="card">
        <h2>Admin Login</h2>
        <p>Login to access CMS.</p>
        <form action="/admin/login" method="get">
          <button className="btn btnPrimary" type="submit">Go to Login</button>
        </form>
      </div>
    );
  }

  const me = await prisma.user.findUnique({ where: { id: actor.id }, select: { name: true, email: true, role: true } });
  return (
    <div className="card">
      <h2 style={{ marginTop: 0 }}>Welcome, {me?.name}</h2>
      <p>Role: <b>{me?.role}</b></p>
      <p>Use the left menu to create articles, submit for review, and publish.</p>
    </div>
  );
}
