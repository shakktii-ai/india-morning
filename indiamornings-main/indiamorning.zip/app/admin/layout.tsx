import Link from "next/link";
import { requireUser } from "@/src/auth/requireUser";
import { prisma } from "@/src/prisma";

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  let me: any = null;
  try {
    const actor = await requireUser();
    me = await prisma.user.findUnique({ where: { id: actor.id }, select: { name: true, email: true, role: true } });
  } catch {}

  return (
    <div style={{ minHeight: "100vh", background: "#F6F7FB" }}>
      <div style={{ background: "var(--brand)", color: "white" }}>
        <div className="container" style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "14px 16px" }}>
          <Link href="/" style={{ fontWeight: 900 }}>India Mornings</Link>
          <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
            {me ? <span style={{ opacity: 0.9 }}>{me.name} • {me.role}</span> : <span style={{ opacity: 0.9 }}>Not logged in</span>}
            <form action="/api/auth/logout" method="post">
              <button className="btn btnGhost" style={{ background: "white" }} type="submit">Logout</button>
            </form>
          </div>
        </div>
      </div>

      <div className="container" style={{ paddingTop: 18, paddingBottom: 40 }}>
        <div className="grid" style={{ gridTemplateColumns: "260px 1fr" }}>
          <nav className="card" style={{ padding: 14 }}>
            <div style={{ fontWeight: 900, marginBottom: 12 }}>Dashboard</div>
            <div style={{ display: "grid", gap: 10 }}>
              <Link href="/admin">Home</Link>
              <Link href="/admin/articles">My / All Articles</Link>
              <Link href="/admin/review">Review Queue</Link>
              <Link href="/admin/users">Users</Link>
              <Link href="/admin/taxonomy">Categories & Tags</Link>
              <Link href="/admin/bootstrap">Bootstrap (one-time)</Link>
            </div>
            <div style={{ fontSize: 12, opacity: 0.7, marginTop: 12 }}>
              Review & Users require Admin/Super Admin.
            </div>
          </nav>

          <section>{children}</section>
        </div>
      </div>
    </div>
  );
}
