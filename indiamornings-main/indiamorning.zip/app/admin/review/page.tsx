"use client";

import { useEffect, useState } from "react";

export default function ReviewPage() {
  const [items, setItems] = useState<any[]>([]);
  const [note, setNote] = useState<Record<string,string>>({});

  async function load() {
    const r = await fetch("/api/review/queue");
    const d = await r.json().catch(()=>({}));
    if (!r.ok) { alert(d?.message || "Forbidden"); return; }
    setItems(d.items || []);
  }

  useEffect(() => { load(); }, []);

  async function approve(id: string) {
    const r = await fetch(`/api/review/${id}/approve`, { method: "POST" });
    const d = await r.json().catch(()=>({}));
    if (!r.ok) { alert(d?.message || "Failed"); return; }
    await load();
  }

  async function publish(id: string) {
    const r = await fetch(`/api/review/${id}/publish`, { method: "POST" });
    const d = await r.json().catch(()=>({}));
    if (!r.ok) { alert(d?.message || "Failed"); return; }
    await load();
  }

  async function reject(id: string) {
    const reviewNotes = note[id] || "Needs improvements.";
    const r = await fetch(`/api/review/${id}/reject`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ reviewNotes })
    });
    const d = await r.json().catch(()=>({}));
    if (!r.ok) { alert(d?.message || "Failed"); return; }
    await load();
  }

  return (
    <div className="card">
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
        <h2 style={{ marginTop: 0 }}>Review Queue (IN_REVIEW)</h2>
        <button className="btn btnGhost" onClick={load}>Refresh</button>
      </div>

      <div style={{ display:"grid", gap: 10 }}>
        {items.map((a:any) => (
          <div key={a.id} className="card" style={{ boxShadow: "none" }}>
            <div style={{ fontSize: 12, opacity: 0.7 }}>
              Submitted: {a.submittedAt ? new Date(a.submittedAt).toLocaleString() : ""} • Author: {a.author?.name}
            </div>
            <div style={{ fontWeight: 900, fontSize: 16 }}>{a.title}</div>
            <div style={{ display:"grid", gap: 8, marginTop: 8 }}>
              <textarea
                className="textarea"
                placeholder="Reject notes (optional)"
                value={note[a.id] || ""}
                onChange={(e)=>setNote(prev=>({ ...prev, [a.id]: e.target.value }))}
                style={{ height: 70 }}
              />
              <div style={{ display:"flex", gap: 8, flexWrap:"wrap" }}>
                <button className="btn btnPrimary" onClick={()=>approve(a.id)}>Approve</button>
                <button className="btn btnGhost" onClick={()=>publish(a.id)}>Publish</button>
                <button className="btn btnGhost" onClick={()=>reject(a.id)}>Reject</button>
                <a className="btn btnGhost" href={`/article/${a.slug}`} target="_blank">Preview</a>
              </div>
            </div>
          </div>
        ))}
        {items.length === 0 ? <div style={{ opacity: 0.7 }}>No items pending.</div> : null}
      </div>
    </div>
  );
}
