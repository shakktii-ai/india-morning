"use client";

import { useEffect, useState } from "react";

export default function UsersPage() {
  const [users, setUsers] = useState<any[]>([]);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("JOURNALIST");

  async function load() {
    const r = await fetch("/api/users");
    const d = await r.json().catch(()=>({}));
    if (!r.ok) { alert(d?.message || "Forbidden"); return; }
    setUsers(d.users || []);
  }

  useEffect(() => { load(); }, []);

  async function create() {
    const r = await fetch("/api/users", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ name, email, password, role })
    });
    const d = await r.json().catch(()=>({}));
    if (!r.ok) { alert(d?.message || "Failed"); return; }
    setName(""); setEmail(""); setPassword("");
    await load();
  }

  async function toggle(id: string, isActive: boolean) {
    const r = await fetch(`/api/users/${id}`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ isActive })
    });
    const d = await r.json().catch(()=>({}));
    if (!r.ok) { alert(d?.message || "Failed"); return; }
    await load();
  }

  return (
    <div className="grid" style={{ gap: 14 }}>
      <div className="card">
        <h2 style={{ marginTop: 0 }}>Create User (Super Admin only)</h2>
        <div className="grid" style={{ gridTemplateColumns: "1fr 1fr" }}>
          <input className="input" placeholder="Name" value={name} onChange={e=>setName(e.target.value)} />
          <select className="select" value={role} onChange={e=>setRole(e.target.value)}>
            <option value="JOURNALIST">JOURNALIST</option>
            <option value="ADMIN">ADMIN</option>
            <option value="SUPER_ADMIN">SUPER_ADMIN</option>
          </select>
          <input className="input" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
          <input className="input" placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
        </div>
        <div style={{ marginTop: 10 }}>
          <button className="btn btnPrimary" onClick={create}>Create</button>
        </div>
      </div>

      <div className="card">
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
          <h2 style={{ marginTop: 0 }}>Users</h2>
          <button className="btn btnGhost" onClick={load}>Refresh</button>
        </div>

        <div style={{ display:"grid", gap: 10 }}>
          {users.map((u:any) => (
            <div key={u.id} className="card" style={{ boxShadow: "none" }}>
              <div style={{ display:"flex", justifyContent:"space-between", gap: 12, alignItems:"center", flexWrap:"wrap" }}>
                <div>
                  <div style={{ fontWeight: 900 }}>{u.name} <span style={{ opacity: 0.6, fontWeight: 700 }}>({u.role})</span></div>
                  <div style={{ fontSize: 12, opacity: 0.7 }}>{u.email}</div>
                </div>
                <div style={{ display:"flex", gap: 8 }}>
                  <button className="btn btnGhost" onClick={()=>toggle(u.id, !u.isActive)}>
                    {u.isActive ? "Deactivate" : "Activate"}
                  </button>
                </div>
              </div>
            </div>
          ))}
          {users.length === 0 ? <div style={{ opacity: 0.7 }}>No users.</div> : null}
        </div>
      </div>
    </div>
  );
}
