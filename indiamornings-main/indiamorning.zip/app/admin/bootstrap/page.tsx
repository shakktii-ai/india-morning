"use client";

import { useState } from "react";

export default function BootstrapPage() {
  const [bootstrapKey, setKey] = useState("");
  const [email, setEmail] = useState("superadmin@indiamornings.com");
  const [password, setPassword] = useState("ChangeMeNow@123");
  const [name, setName] = useState("Super Admin");
  const [msg, setMsg] = useState<string | null>(null);

  async function run() {
    setMsg(null);
    const r = await fetch("/api/admin/bootstrap", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ bootstrapKey, email, password, name })
    });
    const d = await r.json().catch(()=>({}));
    setMsg(r.ok ? `✅ ${d.message} (${d.email})` : `❌ ${d.message || "Failed"}`);
  }

  return (
    <div className="card">
      <h2 style={{ marginTop: 0 }}>One-time Bootstrap</h2>
      <p style={{ opacity: 0.8 }}>Creates the first SUPER_ADMIN (only if it doesn't exist).</p>
      <div className="grid" style={{ gridTemplateColumns: "1fr 1fr" }}>
        <input className="input" placeholder="BOOTSTRAP_KEY" value={bootstrapKey} onChange={e=>setKey(e.target.value)} />
        <input className="input" placeholder="Name" value={name} onChange={e=>setName(e.target.value)} />
        <input className="input" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
        <input className="input" placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} />
      </div>
      <div style={{ marginTop: 12, display: "flex", gap: 10 }}>
        <button className="btn btnPrimary" onClick={run}>Run Bootstrap</button>
      </div>
      {msg ? <div style={{ marginTop: 10, fontWeight: 800 }}>{msg}</div> : null}
    </div>
  );
}
