import SiteHeader from "@/app/_components/SiteHeader";

export default async function ArticlePage({ params }: { params: Promise<{ slug: string }> }) {
  const base = process.env.NEXT_PUBLIC_BASE_URL || "";
  const { slug } = await params;
  const res = await fetch(`${base}/api/public/articles/${encodeURIComponent(slug)}`, { cache: "no-store" });
  if (!res.ok) {
    return (
      <>
        <SiteHeader />
        <main className="container" style={{ padding: 24 }}>
          <h1>Not found</h1>
        </main>
      </>
    );
  }
  const { article } = await res.json();

  return (
    <>
      <SiteHeader />
      <main className="container" style={{ paddingTop: 18, paddingBottom: 50 }}>
        <div style={{ fontSize: 12, opacity: 0.7 }}>
          {article.category?.name || "News"} • {article.publishedAt ? new Date(article.publishedAt).toLocaleString() : ""} • By {article.author?.name || "Admin"}
        </div>
        <h1 style={{ fontSize: 34, margin: "10px 0 10px", lineHeight: 1.15 }}>{article.title}</h1>
        {article.coverImageUrl ? (
          <div style={{
            width: "100%", height: 380, borderRadius: 14, background: "#F3F4F6",
            backgroundImage: `url(${article.coverImageUrl})`,
            backgroundSize: "cover",
            backgroundPosition: "center",
            marginTop: 12
          }} />
        ) : null}

        {article.excerpt ? (
          <p style={{ fontSize: 18, opacity: 0.9 }}>{article.excerpt}</p>
        ) : null}

        <article
          className="card"
          style={{ marginTop: 16, padding: 18 }}
          dangerouslySetInnerHTML={{ __html: article.contentHtml }}
        />
      </main>
    </>
  );
}
