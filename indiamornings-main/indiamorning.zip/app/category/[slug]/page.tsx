import SiteHeader from "@/app/_components/SiteHeader";
import CategoryTabs from "@/app/_components/CategoryTabs";
import FiltersBar from "@/app/_components/FiltersBar";
import ArticleCard from "@/app/_components/ArticleCard";

export default async function CategoryPage({ params, searchParams }: { params: Promise<{ slug: string }>, searchParams: Promise<{ region?: string; lang?: string }> }) {
  const { region = "MAHARASHTRA", lang = "EN" } = await searchParams;
  const { slug } = await params;

  const base = process.env.NEXT_PUBLIC_BASE_URL || "";
  const res = await fetch(`${base}/api/public/home?region=${encodeURIComponent(region)}&lang=${encodeURIComponent(lang)}&category=${encodeURIComponent(slug)}`, { cache: "no-store" });
  const data = await res.json();

  return (
    <>
      <SiteHeader />
      <FiltersBar />
      <CategoryTabs active={slug} />

      <main className="container" style={{ paddingTop: 14, paddingBottom: 40 }}>
        <h1 style={{ fontSize: 28, margin: "10px 0 14px" }}>{data.category?.name || slug}</h1>
        <div className="grid" style={{ gridTemplateColumns: "2fr 1fr" }}>
          <section className="grid">
            {data.topStories?.map((a: any) => <ArticleCard key={a.id} a={a} />)}
          </section>
          <aside>
            <div className="card">
              <h3 style={{ marginTop: 0 }}>Recent</h3>
              <div style={{ display: "grid", gap: 10 }}>
                {data.recent?.map((r: any) => (
                  <a key={r.slug} href={`/article/${r.slug}`} style={{ fontWeight: 700 }}>
                    {r.title}
                    <div style={{ fontSize: 12, opacity: 0.7 }}>{r.publishedAt ? new Date(r.publishedAt).toLocaleDateString() : ""}</div>
                  </a>
                ))}
              </div>
            </div>
          </aside>
        </div>
      </main>
    </>
  );
}
