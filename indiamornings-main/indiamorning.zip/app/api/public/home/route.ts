import { prisma } from "@/src/prisma";
import { jsonOk } from "@/src/utils/http";

export const runtime = "nodejs";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const region = url.searchParams.get("region") || "MAHARASHTRA";
  const language = url.searchParams.get("lang") || "EN";
  const categorySlug = url.searchParams.get("category") || null;

  const category = categorySlug ? await prisma.category.findUnique({ where: { slug: categorySlug } }) : null;

  const where: any = { status: "PUBLISHED", region, language };
  if (category) where.categoryId = category.id;

  const topStories = await prisma.article.findMany({
    where,
    orderBy: { publishedAt: "desc" },
    take: 12,
    include: { category: true, author: { select: { name: true } } }
  });

  const recent = await prisma.article.findMany({
    where,
    orderBy: { publishedAt: "desc" },
    take: 6,
    select: { title: true, slug: true, publishedAt: true }
  });

  return jsonOk({ topStories, recent, category });
}
