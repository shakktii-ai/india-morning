import { prisma } from "@/src/prisma";
import { jsonOk } from "@/src/utils/http";

export const runtime = "nodejs";

export async function GET() {
  const categories = await prisma.category.findMany({ orderBy: { name: "asc" } });
  return jsonOk({ categories });
}
