import { prisma } from "@/src/prisma";
import { jsonError, jsonOk } from "@/src/utils/http";

export const runtime = "nodejs";

export async function GET(_: Request, { params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const article = await prisma.article.findUnique({
    where: { slug },
    include: { category: true, tags: { include: { tag: true } }, author: { select: { name: true } } }
  });
  if (!article || article.status !== "PUBLISHED") return jsonError("Not found", 404);
  return jsonOk({ article });
}
