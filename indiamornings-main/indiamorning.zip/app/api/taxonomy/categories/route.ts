import { prisma } from "@/src/prisma";
import { jsonCreated, jsonError, jsonOk } from "@/src/utils/http";
import { requireUser, getRequestIp } from "@/src/auth/requireUser";
import { requireRole } from "@/src/auth/rbac";
import { z } from "zod";
import { slugify } from "@/src/utils/slug";

export const runtime = "nodejs";

const createSchema = z.object({ name: z.string().min(2) });

export async function GET() {
  const categories = await prisma.category.findMany({ orderBy: { name: "asc" } });
  return jsonOk({ categories });
}

export async function POST(req: Request) {
  try {
    const actor = await requireUser();
    requireRole(actor.role, ["SUPER_ADMIN","ADMIN"]);
    const input = createSchema.parse(await req.json());
    const slug = slugify(input.name);
    const category = await prisma.category.create({ data: { name: input.name, slug } });

    await prisma.auditLog.create({
      data: { actorId: actor.id, actorRole: actor.role as any, action: "CATEGORY_CREATE", entity: "Category", entityId: category.id, ip: await getRequestIp() }
    });

    return jsonCreated({ category });
  } catch (e: any) {
    return jsonError(e?.message || "Error", e?.status || 400);
  }
}
