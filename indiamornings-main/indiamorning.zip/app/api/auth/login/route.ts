import { prisma } from "@/src/prisma";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { jsonError, jsonOk } from "@/src/utils/http";
import { signAccessToken, signRefreshToken } from "@/src/auth/jwt";
import { setAuthCookies } from "@/src/auth/cookies";
import crypto from "crypto";
import { env } from "@/src/env";

export const runtime = "nodejs";

const schema = z.object({ email: z.string().email(), password: z.string().min(6) });

function sha256(s: string) {
  return crypto.createHash("sha256").update(s).digest("hex");
}

export async function POST(req: Request) {
  try {
    const input = schema.parse(await req.json());
    const user = await prisma.user.findUnique({ where: { email: input.email } });
    if (!user || !user.isActive) return jsonError("Invalid credentials", 401);

    const ok = await bcrypt.compare(input.password, user.passwordHash);
    if (!ok) return jsonError("Invalid credentials", 401);

    const access = signAccessToken(user.id, user.role);
    const refresh = signRefreshToken(user.id, user.role);

    const ttlDays = env.REFRESH_TOKEN_TTL_DAYS;
    await prisma.refreshToken.create({
      data: { tokenHash: sha256(refresh), userId: user.id, expiresAt: new Date(Date.now() + 1000*60*60*24*ttlDays) }
    });

    await prisma.user.update({ where: { id: user.id }, data: { lastLoginAt: new Date() } });

    await setAuthCookies(access, refresh);
    return jsonOk({ message: "Logged in", user: { id: user.id, name: user.name, email: user.email, role: user.role } });
  } catch (e: any) {
    return jsonError(e?.message || "Server error", e?.status || 400);
  }
}
