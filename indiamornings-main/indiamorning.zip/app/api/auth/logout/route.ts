import { prisma } from "@/src/prisma";
import { jsonError, jsonOk } from "@/src/utils/http";
import { clearAuthCookies, getAuthCookies } from "@/src/auth/cookies";
import crypto from "crypto";

export const runtime = "nodejs";

function sha256(s: string) {
  return crypto.createHash("sha256").update(s).digest("hex");
}

export async function POST() {
  try {
    const { refresh } = await getAuthCookies();
    if (refresh) {
      const row = await prisma.refreshToken.findUnique({ where: { tokenHash: sha256(refresh) } });
      if (row && !row.revokedAt) await prisma.refreshToken.update({ where: { id: row.id }, data: { revokedAt: new Date() } });
    }
    await clearAuthCookies();
    return jsonOk({ message: "Logged out" });
  } catch {
    return jsonError("Server error", 500);
  }
}
