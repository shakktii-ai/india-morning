import { prisma } from "@/src/prisma";
import { jsonError, jsonOk } from "@/src/utils/http";
import { requireUser } from "@/src/auth/requireUser";

export const runtime = "nodejs";

export async function GET() {
  try {
    const actor = await requireUser();
    const user = await prisma.user.findUnique({
      where: { id: actor.id },
      select: { id: true, name: true, email: true, role: true, isActive: true }
    });
    if (!user) return jsonError("Not found", 404);
    return jsonOk({ user });
  } catch {
    return jsonError("Unauthorized", 401);
  }
}
