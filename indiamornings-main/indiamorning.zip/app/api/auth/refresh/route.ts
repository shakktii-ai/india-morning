import { prisma } from "@/src/prisma";
import { jsonError, jsonOk } from "@/src/utils/http";
import { getAuthCookies, setAuthCookies } from "@/src/auth/cookies";
import { verifyRefresh, signAccessToken, signRefreshToken } from "@/src/auth/jwt";
import crypto from "crypto";
import { env } from "@/src/env";

export const runtime = "nodejs";

function sha256(s: string) {
  return crypto.createHash("sha256").update(s).digest("hex");
}

export async function POST() {
  try {
    const { refresh } = await getAuthCookies();
    if (!refresh) return jsonError("Missing refresh token", 401);

    const payload = verifyRefresh(refresh);
    const tokenRow = await prisma.refreshToken.findUnique({ where: { tokenHash: sha256(refresh) } });
    if (!tokenRow || tokenRow.revokedAt) return jsonError("Refresh token revoked", 401);
    if (tokenRow.expiresAt.getTime() < Date.now()) return jsonError("Refresh token expired", 401);

    const user = await prisma.user.findUnique({ where: { id: payload.sub } });
    if (!user || !user.isActive) return jsonError("User not found", 401);

    const newAccess = signAccessToken(user.id, user.role);
    const newRefresh = signRefreshToken(user.id, user.role);

    await prisma.refreshToken.update({ where: { id: tokenRow.id }, data: { revokedAt: new Date() } });
    const ttlDays = env.REFRESH_TOKEN_TTL_DAYS;
    await prisma.refreshToken.create({
      data: { tokenHash: sha256(newRefresh), userId: user.id, expiresAt: new Date(Date.now() + 1000*60*60*24*ttlDays) }
    });

    await setAuthCookies(newAccess, newRefresh);
    return jsonOk({ message: "Refreshed" });
  } catch (e: any) {
    return jsonError(e?.message || "Server error", 401);
  }
}
