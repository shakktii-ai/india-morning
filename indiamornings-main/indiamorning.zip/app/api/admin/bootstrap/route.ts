import { prisma } from "@/src/prisma";
import bcrypt from "bcryptjs";
import { env } from "@/src/env";
import { jsonError, jsonOk } from "@/src/utils/http";
import { Role } from "@prisma/client";

export const runtime = "nodejs";

export async function POST(req: Request) {
  try {
    const body = await req.json().catch(() => ({}));
    const key = body?.bootstrapKey;
    if (!key || key !== env.BOOTSTRAP_KEY) return jsonError("Invalid bootstrap key", 401);

    const email = env.SUPERADMIN_EMAIL || body?.email;
    const password = env.SUPERADMIN_PASSWORD || body?.password;
    const name = env.SUPERADMIN_NAME || body?.name || "Super Admin";

    if (!email || !password) return jsonError("Missing email/password", 400);

    const exists = await prisma.user.findUnique({ where: { email } });
    if (exists) return jsonOk({ message: "Super admin already exists", email });

    const passwordHash = await bcrypt.hash(password, 12);
    await prisma.user.create({ data: { name, email, passwordHash, role: Role.SUPER_ADMIN } });

    return jsonOk({ message: "Super admin created", email });
  } catch (e: any) {
    return jsonError(e?.message || "Server error", e?.status || 500);
  }
}
