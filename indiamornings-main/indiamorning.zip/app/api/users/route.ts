import { prisma } from "@/src/prisma";
import { jsonCreated, jsonError, jsonOk } from "@/src/utils/http";
import { requireUser, getRequestIp } from "@/src/auth/requireUser";
import { requireRole } from "@/src/auth/rbac";
import { z } from "zod";
import bcrypt from "bcryptjs";

export const runtime = "nodejs";

const createSchema = z.object({
  name: z.string().min(2),
  email: z.string().email(),
  password: z.string().min(6),
  role: z.enum(["SUPER_ADMIN","ADMIN","JOURNALIST"]).default("JOURNALIST")
});

export async function GET() {
  try {
    const actor = await requireUser();
    requireRole(actor.role, ["SUPER_ADMIN","ADMIN"]);
    const users = await prisma.user.findMany({
      select: { id: true, name: true, email: true, role: true, isActive: true, createdAt: true, lastLoginAt: true }
    });
    return jsonOk({ users });
  } catch (e: any) {
    return jsonError(e?.message || "Error", e?.status || 500);
  }
}

export async function POST(req: Request) {
  try {
    const actor = requireUser();
    const actorUser = await actor;
    requireRole(actorUser.role, ["SUPER_ADMIN"]);
    const input = createSchema.parse(await req.json());
    const exists = await prisma.user.findUnique({ where: { email: input.email } });
    if (exists) return jsonError("Email already exists", 409);

    const passwordHash = await bcrypt.hash(input.password, 12);
    const user = await prisma.user.create({ data: { name: input.name, email: input.email, passwordHash, role: input.role as any } });

    await prisma.auditLog.create({
      data: { actorId: actorUser.id, actorRole: actorUser.role as any, action: "USER_CREATE", entity: "User", entityId: user.id, ip: await getRequestIp() ?? "0.0.0.0" }
    });

    return jsonCreated({ user: { id: user.id, name: user.name, email: user.email, role: user.role } });
  } catch (e: any) {
    return jsonError(e?.message || "Error", e?.status || 400);
  }
}
