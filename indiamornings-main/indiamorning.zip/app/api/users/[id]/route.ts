import { prisma } from "@/src/prisma";
import { jsonError, jsonOk } from "@/src/utils/http";
import { requireUser, getRequestIp } from "@/src/auth/requireUser";
import { requireRole } from "@/src/auth/rbac";
import { z } from "zod";

export const runtime = "nodejs";

const patchSchema = z.object({
  name: z.string().min(2).optional(),
  role: z.enum(["SUPER_ADMIN","ADMIN","JOURNALIST"]).optional(),
  isActive: z.boolean().optional()
});

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const actor = await requireUser();
    requireRole(actor.role, ["SUPER_ADMIN","ADMIN"]);

    const input = patchSchema.parse(await req.json());
    if (input.role === "SUPER_ADMIN" && actor.role !== "SUPER_ADMIN") return jsonError("Only SUPER_ADMIN can assign SUPER_ADMIN", 403);

      const user = await prisma.user.update({
      where: { id: (await params).id },
      data: input as any,
      select: { id: true, name: true, email: true, role: true, isActive: true }
    });

    await prisma.auditLog.create({
      data: { actorId: actor.id, actorRole: actor.role as any, action: "USER_UPDATE", entity: "User", entityId: user.id, ip: await getRequestIp() }
    });

    return jsonOk({ user });
  } catch (e: any) {
    return jsonError(e?.message || "Error", e?.status || 400);
  }
}

export async function DELETE(_: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const actor = await requireUser();
    requireRole(actor.role, ["SUPER_ADMIN"]);
    const { id } = await params;
    await prisma.user.delete({ where: { id } });

    await prisma.auditLog.create({
      data: { actorId: actor.id, actorRole: actor.role as any, action: "USER_DELETE", entity: "User", entityId: id, ip: await getRequestIp() }
    });

    return jsonOk({ message: "Deleted" });
  } catch (e: any) {
    return jsonError(e?.message || "Error", e?.status || 400);
  }
}
