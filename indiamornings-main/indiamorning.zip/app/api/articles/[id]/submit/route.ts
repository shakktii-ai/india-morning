import { prisma } from "@/src/prisma";
import { jsonError, jsonOk } from "@/src/utils/http";
import { requireUser, getRequestIp } from "@/src/auth/requireUser";

export const runtime = "nodejs";

export async function POST(_: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const actor = await requireUser();
    const { id } = await params;
    const article = await prisma.article.findUnique({ where: { id } });
    if (!article) return jsonError("Not found", 404);
    if (actor.role === "JOURNALIST" && article.authorId !== actor.id) return jsonError("Forbidden", 403);
    if (!["DRAFT","REJECTED"].includes(article.status)) return jsonError("Only draft/rejected can be submitted", 409);

    const updated = await prisma.article.update({
      where: { id },
      data: { status: "IN_REVIEW", submittedAt: new Date(), reviewNotes: null, reviewerId: null }
    });

    await prisma.auditLog.create({
      data: { actorId: actor.id, actorRole: actor.role as any, action: "ARTICLE_SUBMIT", entity: "Article", entityId: id, ip: await getRequestIp() }
    });

    return jsonOk({ article: updated });
  } catch (e: any) {
    return jsonError(e?.message || "Error", e?.status || 500);
  }
}
