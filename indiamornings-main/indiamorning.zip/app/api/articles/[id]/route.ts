import { prisma } from "@/src/prisma";
import { jsonError, jsonOk } from "@/src/utils/http";
import { requireUser, getRequestIp } from "@/src/auth/requireUser";
import { z } from "zod";

export const runtime = "nodejs";

const patchSchema = z.object({
  title: z.string().min(5).optional(),
  excerpt: z.string().optional(),
  contentHtml: z.string().min(20).optional(),
  coverImageUrl: z.string().url().optional().nullable(),
  language: z.string().optional(),
  region: z.string().optional(),
  categoryId: z.string().optional().nullable(),
  tagIds: z.array(z.string()).optional(),
  seoTitle: z.string().optional().nullable(),
  metaDescription: z.string().optional().nullable(),
  focusKeyphrase: z.string().optional().nullable(),
  canonicalUrl: z.string().url().optional().nullable()
});

export async function GET(_: Request, { params }: { params: Promise<{ id: string }> }) {
  const actor = await requireUser();
  const { id } = await params;
  const article = await prisma.article.findUnique({
    where: { id },
    include: { category: true, tags: { include: { tag: true } }, author: { select: { id: true, name: true, role: true } } }
  });
  if (!article) return jsonError("Not found", 404);
  if (actor.role === "JOURNALIST" && article.authorId !== actor.id) return jsonError("Forbidden", 403);
  return jsonOk({ article });
}

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const actor = await requireUser();
    const input = patchSchema.parse(await req.json());
    const { id } = await params;
    const existing = await prisma.article.findUnique({ where: { id } });
    if (!existing) return jsonError("Not found", 404);
    if (actor.role === "JOURNALIST" && existing.authorId !== actor.id) return jsonError("Forbidden", 403);
    if (actor.role === "JOURNALIST" && !["DRAFT","REJECTED"].includes(existing.status)) return jsonError("Cannot edit after submission", 409);

    const updated = await prisma.$transaction(async (tx) => {
      const art = await tx.article.update({
        where: { id },
        data: {
          ...input,
          // If an editor touches an approved/published article, push it back to review
          status: (actor.role !== "JOURNALIST" && ["APPROVED","PUBLISHED"].includes(existing.status)) ? "IN_REVIEW" : undefined,
          reviewerId: (actor.role !== "JOURNALIST" && ["APPROVED","PUBLISHED"].includes(existing.status)) ? null : undefined,
          approvedAt: (actor.role !== "JOURNALIST" && ["APPROVED","PUBLISHED"].includes(existing.status)) ? null : undefined,
          publishedAt: (actor.role !== "JOURNALIST" && existing.status === "PUBLISHED") ? null : undefined
        } as any
      });

      if (input.tagIds) {
        await tx.articleTag.deleteMany({ where: { articleId: id } });
        await tx.articleTag.createMany({ data: input.tagIds.map((tagId) => ({ articleId: id, tagId })) });
      }
      return art;
    });

    await prisma.auditLog.create({
      data: { actorId: actor.id, actorRole: actor.role as any, action: "ARTICLE_UPDATE", entity: "Article", entityId: id, ip: await getRequestIp() }
    });

    return jsonOk({ article: updated });
  } catch (e: any) {
    return jsonError(e?.message || "Error", e?.status || 400);
  }
}

export async function DELETE(_: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const actor = await requireUser();
    const { id } = await params;
    const existing = await prisma.article.findUnique({ where: { id } });
    if (!existing) return jsonError("Not found", 404);
    if (actor.role === "JOURNALIST" && existing.authorId !== actor.id) return jsonError("Forbidden", 403);
    if (actor.role === "JOURNALIST" && !["DRAFT","REJECTED"].includes(existing.status)) return jsonError("Cannot delete after submission", 409);

    await prisma.article.delete({ where: { id } });
    await prisma.auditLog.create({
      data: { actorId: actor.id, actorRole: actor.role as any, action: "ARTICLE_DELETE", entity: "Article", entityId: id, ip: await getRequestIp() }
    });
    return jsonOk({ message: "Deleted" });
  } catch (e: any) {
    return jsonError(e?.message || "Error", e?.status || 400);
  }
}
