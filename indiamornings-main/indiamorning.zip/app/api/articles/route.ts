import { prisma } from "@/src/prisma";
import { jsonCreated, jsonError, jsonOk } from "@/src/utils/http";
import { requireUser, getRequestIp } from "@/src/auth/requireUser";
import { requireRole } from "@/src/auth/rbac";
import { z } from "zod";
import { slugify } from "@/src/utils/slug";

export const runtime = "nodejs";

const createSchema = z.object({
  title: z.string().min(5),
  excerpt: z.string().optional(),
  contentHtml: z.string().min(20),
  coverImageUrl: z.string().url().optional(),
  language: z.string().default("EN"),
  region: z.string().default("MAHARASHTRA"),
  categoryId: z.string().optional(),
  tagIds: z.array(z.string()).default([]),
  seoTitle: z.string().optional(),
  metaDescription: z.string().optional(),
  focusKeyphrase: z.string().optional(),
  canonicalUrl: z.string().url().optional()
});

export async function GET(req: Request) {
  try {
    const actor = await requireUser();
    const url = new URL(req.url);
    const status = url.searchParams.get("status") || undefined;

    const where: any = {};
    if (status) where.status = status;
    if (actor.role === "JOURNALIST") where.authorId = actor.id;

    const articles = await prisma.article.findMany({
      where,
      orderBy: { updatedAt: "desc" },
      include: { category: true, tags: { include: { tag: true } } }
    });

    return jsonOk({ articles });
  } catch (e: any) {
    return jsonError(e?.message || "Error", e?.status || 500);
  }
}

export async function POST(req: Request) {
  try {
    const actor = requireUser();
    const user = await actor;
    requireRole(user.role, ["SUPER_ADMIN","ADMIN","JOURNALIST"]);
    const input = createSchema.parse(await req.json());

    const baseSlug = slugify(input.title);
    let slug = baseSlug;
    let i = 1;
    while (await prisma.article.findUnique({ where: { slug } })) slug = `${baseSlug}-${i++}`;

    const article = await prisma.article.create({
      data: {
        title: input.title,
        slug,
        excerpt: input.excerpt,
        contentHtml: input.contentHtml,
        coverImageUrl: input.coverImageUrl,
        language: input.language,
        region: input.region,
        categoryId: input.categoryId,
        authorId: user.id,
        seoTitle: input.seoTitle,
        metaDescription: input.metaDescription,
        focusKeyphrase: input.focusKeyphrase,
        canonicalUrl: input.canonicalUrl,
        tags: { create: input.tagIds.map((tagId) => ({ tagId })) }
      },
      include: { category: true, tags: { include: { tag: true } } }
    });

    await prisma.auditLog.create({
      data: { actorId: user.id, actorRole: user.role as any, action: "ARTICLE_CREATE", entity: "Article", entityId: article.id, ip: await getRequestIp() }
    });

    return jsonCreated({ article });
  } catch (e: any) {
    return jsonError(e?.message || "Error", e?.status || 400);
  }
}
