import { prisma } from "@/src/prisma";
import { jsonError, jsonOk } from "@/src/utils/http";
import { requireUser, getRequestIp } from "@/src/auth/requireUser";
import { requireRole } from "@/src/auth/rbac";

export const runtime = "nodejs";

export async function POST(_: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const actor = await requireUser();
    requireRole(actor.role, ["SUPER_ADMIN","ADMIN"]);
    const { id } = await params;
    const art = await prisma.article.findUnique({ where: { id } });
    if (!art) return jsonError("Not found", 404);
    if (art.status !== "IN_REVIEW") return jsonError("Only IN_REVIEW can be approved", 409);

    const updated = await prisma.article.update({
      where: { id },
      data: { status: "APPROVED", reviewerId: actor.id, approvedAt: new Date(), reviewNotes: null }
    });

    await prisma.auditLog.create({
      data: { actorId: actor.id, actorRole: actor.role as any, action: "ARTICLE_APPROVE", entity: "Article", entityId: id, ip: await getRequestIp() }
    });

    return jsonOk({ article: updated });
  } catch (e: any) {
    return jsonError(e?.message || "Error", e?.status || 500);
  }
}
