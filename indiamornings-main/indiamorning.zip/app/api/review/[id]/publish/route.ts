import { prisma } from "@/src/prisma";
import { jsonError, jsonOk } from "@/src/utils/http";
import { requireUser, getRequestIp } from "@/src/auth/requireUser";
import { requireRole } from "@/src/auth/rbac";

export const runtime = "nodejs";

export async function POST(_: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const actor = await requireUser();
    requireRole(actor.role, ["SUPER_ADMIN","ADMIN"]);
    const { id } = await params;
    const art = await prisma.article.findUnique({ where: { id } });
    if (!art) return jsonError("Not found", 404);
    if (art.status !== "APPROVED") return jsonError("Only APPROVED can be published", 409);

    const updated = await prisma.article.update({
      where: { id },
      data: { status: "PUBLISHED", publishedAt: new Date() }
    });

    await prisma.auditLog.create({
      data: { actorId: actor.id, actorRole: actor.role as any, action: "ARTICLE_PUBLISH", entity: "Article", entityId: id, ip: await getRequestIp() }
    });

    return jsonOk({ article: updated });
  } catch (e: any) {
    return jsonError(e?.message || "Error", e?.status || 500);
  }
}
