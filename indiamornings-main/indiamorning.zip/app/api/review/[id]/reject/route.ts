import { prisma } from "@/src/prisma";
import { jsonError, jsonOk } from "@/src/utils/http";
import { requireUser, getRequestIp } from "@/src/auth/requireUser";
import { requireRole } from "@/src/auth/rbac";
import { z } from "zod";

export const runtime = "nodejs";

const schema = z.object({ reviewNotes: z.string().min(3) });

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const actor = await requireUser();
    requireRole(actor.role, ["SUPER_ADMIN","ADMIN"]);
    const { reviewNotes } = schema.parse(await req.json());

    const { id } = await params;
    const art = await prisma.article.findUnique({ where: { id } });
    if (!art) return jsonError("Not found", 404);
    if (art.status !== "IN_REVIEW") return jsonError("Only IN_REVIEW can be rejected", 409);

    const updated = await prisma.article.update({
      where: { id },
      data: { status: "REJECTED", reviewerId: actor.id, reviewNotes }
    });

    await prisma.auditLog.create({
      data: { actorId: actor.id, actorRole: actor.role as any, action: "ARTICLE_REJECT", entity: "Article", entityId: id, ip: await getRequestIp() }
    });

    return jsonOk({ article: updated });
  } catch (e: any) {
    return jsonError(e?.message || "Error", e?.status || 400);
  }
}
