import { prisma } from "@/src/prisma";
import { jsonError, jsonOk } from "@/src/utils/http";
import { requireUser } from "@/src/auth/requireUser";
import { requireRole } from "@/src/auth/rbac";

export const runtime = "nodejs";

export async function GET() {
  try {
    const actor = await requireUser();
    requireRole(actor.role, ["SUPER_ADMIN","ADMIN"]);
    const items = await prisma.article.findMany({
      where: { status: "IN_REVIEW" },
      orderBy: { submittedAt: "desc" },
      include: { author: { select: { id: true, name: true, email: true } }, category: true }
    });
    return jsonOk({ items });
  } catch (e: any) {
    return jsonError(e?.message || "Error", e?.status || 500);
  }
}
