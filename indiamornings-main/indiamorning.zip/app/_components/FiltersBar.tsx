"use client";

import { useRouter, useSearchParams } from "next/navigation";

export default function FiltersBar() {
  const router = useRouter();
  const sp = useSearchParams();

  const lang = sp.get("lang") || "EN";
  const region = sp.get("region") || "MAHARASHTRA";

  function setParam(key: string, value: string) {
    const next = new URLSearchParams(sp.toString());
    next.set(key, value);
    router.push(`?${next.toString()}`);
  }

  return (
    <div className="container" style={{ paddingTop: 12 }}>
      <div style={{ display: "flex", gap: 10, flexWrap: "wrap", justifyContent: "flex-end" }}>
        <div className="card" style={{ padding: 8, display: "flex", gap: 8, alignItems: "center" }}>
          <span style={{ fontWeight: 700 }}>Language</span>
          <select className="select" value={lang} onChange={(e) => setParam("lang", e.target.value)} style={{ width: 140 }}>
            <option value="EN">English</option>
            <option value="MR">Marathi</option>
            <option value="HI">Hindi</option>
          </select>
        </div>

        <div className="card" style={{ padding: 8, display: "flex", gap: 8, alignItems: "center" }}>
          <span style={{ fontWeight: 700 }}>State</span>
          <select className="select" value={region} onChange={(e) => setParam("region", e.target.value)} style={{ width: 180 }}>
            <option value="MAHARASHTRA">MAHARASHTRA</option>
            <option value="INDIA">INDIA</option>
            <option value="GUJARAT">GUJARAT</option>
            <option value="DELHI">DELHI</option>
          </select>
        </div>
      </div>
    </div>
  );
}
