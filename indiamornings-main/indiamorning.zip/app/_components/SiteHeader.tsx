"use client";

import Link from "next/link";
import { useEffect, useState } from "react";

export default function SiteHeader() {
  const [me, setMe] = useState<{name:string; role:string} | null>(null);

  useEffect(() => {
    fetch("/api/auth/me").then(r => r.ok ? r.json() : null).then(d => {
      if (d?.user) setMe({ name: d.user.name, role: d.user.role });
    }).catch(()=>{});
  }, []);

  return (
    <header style={{ background: "var(--brand)", color: "white" }}>
      <div className="container" style={{ height: 90, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <Link href="/" style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ width: 46, height: 46, borderRadius: 10, background: "rgba(255,255,255,0.12)", display:"grid", placeItems:"center", fontWeight:800 }}>IM</div>
          <div style={{ lineHeight: 1 }}>
            <div style={{ fontSize: 18, fontWeight: 800 }}>India Mornings</div>
            <div style={{ fontSize: 12, opacity: 0.8 }}>News • Maharashtra • India</div>
          </div>
        </Link>

      </div>

      <div style={{ background: "var(--danger)" }}>
        <div className="container" style={{ padding: "10px 16px", fontSize: 14 }}>
          <b style={{ color: "black" }}>BREAKING NEWS</b>
          <span style={{ color: "#F3F4F6" }}>
            {" "} : Major rainfall alert issued in Maharashtra • Parliament session begins today • India wins cricket qualifier • Stock markets hit record high
          </span>
        </div>
      </div>
    </header>
  );
}
