import Link from "next/link";

export default function ArticleCard({ a }: { a: any }) {
  return (
    <div className="card">
      <div style={{ display: "flex", gap: 12 }}>
        <div style={{
          width: 140, height: 92, borderRadius: 10, background: "#F3F4F6",
          backgroundImage: a.coverImageUrl ? `url(${a.coverImageUrl})` : undefined,
          backgroundSize: "cover",
          backgroundPosition: "center"
        }} />
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 12, opacity: 0.75 }}>
            {a.category?.name || "Top Story"} • {a.publishedAt ? new Date(a.publishedAt).toLocaleDateString() : ""}
          </div>
          <Link href={`/article/${a.slug}`} style={{ display: "block", fontSize: 18, fontWeight: 800, marginTop: 6 }}>
            {a.title}
          </Link>
          {a.excerpt ? <div style={{ marginTop: 6, opacity: 0.9 }}>{a.excerpt}</div> : null}
        </div>
      </div>
    </div>
  );
}
