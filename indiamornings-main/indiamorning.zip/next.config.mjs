/** @type {import('next').NextConfig} */
const nextConfig = {
  // Keep runtime on Node for Prisma-backed API routes
};

export default nextConfig;
