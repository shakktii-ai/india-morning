import { PrismaClient, Role } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  const email = process.env.SUPERADMIN_EMAIL || "superadmin@indiamornings.com";
  const name = process.env.SUPERADMIN_NAME || "Super Admin";
  const password = process.env.SUPERADMIN_PASSWORD || "ChangeMeNow@123";

  const exists = await prisma.user.findUnique({ where: { email } });
  if (exists) {
    console.log("Super admin already exists:", email);
    return;
  }

  const passwordHash = await bcrypt.hash(password, 12);
  await prisma.user.create({
    data: { name, email, passwordHash, role: Role.SUPER_ADMIN }
  });

  console.log("Seeded super admin:", email);
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(async () => { await prisma.$disconnect(); });
